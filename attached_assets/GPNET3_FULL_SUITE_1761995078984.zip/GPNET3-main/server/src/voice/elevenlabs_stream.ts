// ElevenLabs streaming placeholder — disabled by default.
// export async function streamToVoice(_answer: string) {
//   // no-op
// }
