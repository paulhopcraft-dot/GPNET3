import { CasesTable } from '../cases-table';

export default function CasesTableExample() {
  return (
    <div className="p-6">
      <CasesTable />
    </div>
  );
}
