import { OrganizationGrid } from '../organization-card';

export default function OrganizationCardExample() {
  return (
    <div className="p-6">
      <OrganizationGrid />
    </div>
  );
}
