import { AIAssistant } from '../ai-assistant';

export default function AIAssistantExample() {
  return <AIAssistant />;
}
