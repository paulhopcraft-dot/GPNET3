import { DashboardStats } from '../dashboard-stats';

export default function DashboardStatsExample() {
  return (
    <div className="p-6">
      <DashboardStats />
    </div>
  );
}
