import { RecentActivity } from '../recent-activity';

export default function RecentActivityExample() {
  return (
    <div className="p-6 max-w-2xl">
      <RecentActivity />
    </div>
  );
}
